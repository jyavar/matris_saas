export const subtract = (a: number, b: number): number => a - b
