# .husky

Esta carpeta contiene hooks de pre-commit y pre-push para asegurar calidad de código, linting y validaciones locales antes de cada push o commit. 