// Funciones auxiliares para el módulo Profiles

export {}

// Ejemplo:
// export function formatProfileName(profile: Profile): string {
//   return profile.full_name || profile.username;
// }
