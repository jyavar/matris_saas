// Tipos auxiliares para el módulo Auth

// Ejemplo:
// export interface AuthCredentials {
//   email: string;
//   password: string;
// }
