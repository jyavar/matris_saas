// Tipos auxiliares para el módulo Profiles

export {}

// Ejemplo:
// export interface Profile {
//   id: string;
//   username: string;
//   full_name?: string;
//   avatar_url?: string;
//   tenant_id: string;
// }
