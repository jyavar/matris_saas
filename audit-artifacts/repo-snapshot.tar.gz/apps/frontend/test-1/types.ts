// Tipos para test-1

export type Test1Type = unknown
