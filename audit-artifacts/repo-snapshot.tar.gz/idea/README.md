# .idea

Esta carpeta contiene configuraciones del IDE JetBrains/WebStorm. No es necesaria para todos los colaboradores y puede ser ignorada en otros entornos. 