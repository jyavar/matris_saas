export default function ControlTowerPage() {
  return <div>Control Tower</div>;
}
