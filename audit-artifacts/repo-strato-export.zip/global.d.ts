declare global {
  // eslint-disable-next-line no-var
  var expect: unknown
}
export {}
