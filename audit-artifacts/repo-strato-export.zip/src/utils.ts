// Utilidades para billing

export function mapStripeEventToAction(eventType: string): string {
  // TODO: Mapear eventos de Stripe a acciones internas
  return eventType;
} 