import { describe, it, expect } from 'vitest';
// import request from 'supertest';
// import app from '../app'; // Ajusta según tu entrypoint

describe('BillingController', () => {
  it('should create a checkout session', async () => {
    // TODO: Implementar test real usando supertest
    expect(true).toBe(true);
  });

  it('should handle webhook', async () => {
    // TODO: Implementar test real usando supertest
    expect(true).toBe(true);
  });

  it('should get subscription status', async () => {
    // TODO: Implementar test real usando supertest
    expect(true).toBe(true);
  });
}); 