# .github

Esta carpeta contiene workflows y configuraciones de GitHub Actions para CI/CD, validaciones automáticas y automatización de PRs en el monorepo STRATO. 