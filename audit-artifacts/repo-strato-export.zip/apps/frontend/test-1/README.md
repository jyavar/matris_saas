# test-1 (agent)

> Generado con scaffolding STRATO™

## Checklist STRATO
- [ ] index.ts implementado
- [ ] types.ts definido
- [ ] __tests__ con cobertura
- [ ] Cumple reglas de oro
- [ ] Documentación viva

---

Actualiza este README tras cada cambio relevante.
