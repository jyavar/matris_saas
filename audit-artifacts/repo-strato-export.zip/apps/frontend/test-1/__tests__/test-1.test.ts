import { describe, expect, it } from 'vitest'

describe('test-1', () => {
  it('debería funcionar', () => {
    expect(true).toBe(true)
  })
})
