// test-1 (agent)

// Implementa aquí la lógica principal del módulo.
