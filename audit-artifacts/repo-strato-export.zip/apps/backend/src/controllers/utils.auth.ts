// Funciones auxiliares para el módulo Auth

// Ejemplo:
// export function maskEmail(email: string): string {
//   // ...
// }
