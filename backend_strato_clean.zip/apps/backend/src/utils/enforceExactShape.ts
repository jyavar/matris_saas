// Helper para forzar el tipo exacto de un objeto
export function enforceExactShape<T>(obj: T): T {
  return obj
}
