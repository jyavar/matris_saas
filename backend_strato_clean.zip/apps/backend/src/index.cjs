const { app } = await import('./index.js');
module.exports = { app }; 