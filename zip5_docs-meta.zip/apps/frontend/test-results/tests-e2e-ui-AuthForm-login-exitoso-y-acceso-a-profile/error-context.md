# Page snapshot

```yaml
- heading "Login" [level=1]
- text: "Email:"
- textbox "Email:": test@example.com
- text: "Password:"
- textbox "Password:": "123456"
- button "Log In"
- alert
- button "Open Next.js Dev Tools":
  - img
- button "Open issues overlay": 1 Issue
- button "Collapse issues badge":
  - img
```