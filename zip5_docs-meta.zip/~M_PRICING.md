<!-- STRATO MODULE HEADER
{
  "module": "PRICING",
  "description": "Módulo de gestión de precios y planes de suscripción.",
  "paths": [],
  "tests": [],
  "routes": [],
  "docs": [],
  "last_synced": "2025-07-01",
  "responsible": "José + IA STRATO",
  "coverage": 0,
  "status": "active",
  "criticality": "medium"
}
-->

# PRICING

## 📁 ARCHIVOS CLAVE

### Source Files

### Test Files

### Config Files

### Doc Files

### Scripts

---

## Descripción

Gestión de precios, planes y lógica de facturación para STRATO.

## Checklist de trazabilidad
- [ ] Header JSON válido
- [ ] Archivos clave listados
- [ ] Tests asociados
- [ ] Rutas documentadas
- [ ] Sin archivos huérfanos 