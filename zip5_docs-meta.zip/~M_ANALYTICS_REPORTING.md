<!-- STRATO MODULE HEADER
{
  "module": "ANALYTICS_REPORTING",
  "description": "Módulo de reporting y generación de informes analíticos.",
  "paths": [
    "apps/frontend/src/lib/reporting.api.ts"
  ],
  "tests": [],
  "routes": [],
  "docs": [],
  "last_synced": "2025-07-01",
  "responsible": "José + IA STRATO",
  "coverage": 0,
  "status": "active",
  "criticality": "medium"
}
-->

# ANALYTICS_REPORTING


## 📁 ARCHIVOS CLAVE

### **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**
- `apps/frontend/src/lib/reporting.api.ts` - Archivo fuente

### **Test Files**


### **Config Files**


### **Doc Files**
## Source Files
- `apps/frontend/src/lib/reporting.api.ts`

### Test Files


### Config Files


### Doc Files


### Scripts

### Source Files

### Test Files

### Config Files

### Doc Files

### Scripts

---

## Descripción

Reporting, dashboards y generación de informes analíticos para STRATO.

## Checklist de trazabilidad
- [ ] Header JSON válido
- [ ] Archivos clave listados
- [ ] Tests asociados
- [ ] Rutas documentadas
- [ ] Sin archivos huérfanos 