<!-- STRATO MODULE HEADER
{
  "module": "EMAIL_CAMPAIGNS",
  "description": "Módulo de campañas de email y notificaciones.",
  "paths": [],
  "tests": [],
  "routes": [],
  "docs": [],
  "last_synced": "2025-07-01",
  "responsible": "José + IA STRATO",
  "coverage": 0,
  "status": "active",
  "criticality": "medium"
}
-->

# EMAIL_CAMPAIGNS







## 📁 ARCHIVOS CLAVE

### **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## **Source Files**


### **Test Files**


### **Config Files**


### **Doc Files**
## Source Files


### Test Files


### Config Files


### Doc Files


### Scripts

### Source Files


### Test Files


### Config Files


### Doc Files


### Scripts

### Source Files


### Test Files


### Config Files


### Doc Files


### Scripts

### Source Files


### Test Files


### Config Files


### Doc Files


### Scripts

### Source Files


### Test Files


### Config Files


### Doc Files


### Scripts

### Source Files


### Test Files


### Config Files


### Doc Files


### Scripts

### Source Files

### Test Files

### Config Files

### Doc Files

### Scripts

---

## Descripción

Gestión de campañas de email, plantillas y envíos automáticos en STRATO.

## Checklist de trazabilidad
- [ ] Header JSON válido
- [ ] Archivos clave listados
- [ ] Tests asociados
- [ ] Rutas documentadas
- [ ] Sin archivos huérfanos 