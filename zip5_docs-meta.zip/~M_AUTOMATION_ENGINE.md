<!-- STRATO MODULE HEADER
{
  "module": "AUTOMATION_ENGINE",
  "description": "Módulo de automatización y orquestación de procesos.",
  "paths": [],
  "tests": [],
  "routes": [],
  "docs": [],
  "last_synced": "2025-07-01",
  "responsible": "José + IA STRATO",
  "coverage": 0,
  "status": "active",
  "criticality": "medium"
}
-->

# AUTOMATION_ENGINE

## 📁 ARCHIVOS CLAVE

### Source Files

### Test Files

### Config Files

### Doc Files

### Scripts

---

## Descripción

Automatización de procesos, workflows y tareas programadas en STRATO.

## Checklist de trazabilidad
- [ ] Header JSON válido
- [ ] Archivos clave listados
- [ ] Tests asociados
- [ ] Rutas documentadas
- [ ] Sin archivos huérfanos 