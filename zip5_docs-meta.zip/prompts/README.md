# prompts

Esta carpeta contiene prompts, plantillas y recursos para IA, generación de código y automatización de tareas en el monorepo STRATO. 