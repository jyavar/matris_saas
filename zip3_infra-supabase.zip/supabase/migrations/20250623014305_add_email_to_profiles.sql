-- Agrega la columna email a la tabla profiles para tests y desarrollo local
ALTER TABLE profiles ADD COLUMN email TEXT; 